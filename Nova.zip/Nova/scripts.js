function scrollToForm() {
    document.getElementById('contact').scrollIntoView({ behavior: 'smooth' });
}
